# Horseshoe Meter

Documentation:
http://docs.splunk.com/Documentation/HorseshoeMeter/1.2.0/HorseshoeMeterViz/HorseshoeMeterIntro

##Sample searches
```
index=_internal | stats count
```