define([
  'jquery',
  'underscore'
 ],
 function(
  $,
  _
 ) {
	 alert("I m in")
 var formgroup = $("<div/>", {
  class: "form-group"
});
formgroup.append($("<label>", {
  class: "col-sm-2 control-label",
  text: "Enter Name"
}));
var colsm = $("<div/>", {
  class: "col-sm-10"
});
var input = $("<input/>", {
  type: "text",
  class: "form-control",
  id: "nameId",
  placeholder: "Git URL"
});
colsm.append(input);
formgroup.append(colsm);
$("#git_inputs").append(formgroup);
 
 });